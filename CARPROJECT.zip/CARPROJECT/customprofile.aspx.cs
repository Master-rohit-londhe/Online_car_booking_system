﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);


    protected void Page_Load(object sender, EventArgs e)
    {

        HiddenField1.Value = Session["id"].ToString();
        custom1.Text = HiddenField1.Value;
      
    }
   
   
    protected void Button3_Click1(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from custom where customid='" + custom1.Text + "  ' ", con);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        if (reader.HasRows)
        {

            custom1.Text = reader[0].ToString();
            custom2.Text = reader[1].ToString();
            custom3.Text = reader[2].ToString();
            custom4.Text = reader[3].ToString();
            custom5.Text = reader[4].ToString();
            custom6.SelectedValue = reader[5].ToString();
            custom7.Text = reader[6].ToString();
            custom8.Text = reader[7].ToString();



            reader.Close();
            con.Close();
        }
    }
    protected void Update_Click1(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("update custom set  customid='" + custom1.Text + "', customname='" + custom2.Text + "', customadd='" + custom3.Text + "', custommob='" + custom4.Text + "',customemail='" + custom5.Text + "', customgend='" + custom6.SelectedValue + "', customuser='" + custom7.Text + "',  custompsw='" + custom8.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script language=javascript>alert(' Update Profile Successfully.')</script>");

        custom1.Text = "";
        custom2.Text = "";
        custom3.Text = "";
        custom4.Text = "";
        custom5.Text = "";
        custom6.SelectedValue = "";
        custom7.Text = "";
        custom8.Text = "";
      
    }
}