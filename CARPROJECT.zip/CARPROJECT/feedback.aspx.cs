﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void submit_Click1(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into feedback values('" + name.Text + "','" + address.Text + "','" + phone.Text + "','" + email.Text + "','" + feedback.Text + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script language=javascript>alert(' Feedback Send Successfully.')</script>");

        name.Text = "";
        address.Text = "";
        phone.Text = "";
        email.Text = "";
        feedback.Text = "";
    }
}