﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        HiddenField1.Value = Session["id"].ToString();
        Showp1.Text = HiddenField1.Value;

    }
    protected void Searchp1_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from addshow where showid='" + Showp1.Text + "  ' ", con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                Showp1.Text = reader[0].ToString();
                Showp2.Text = reader[1].ToString();
                Showp3.Text = reader[2].ToString();
                Showp4.SelectedValue = reader[3].ToString();
                Showp5.Text = reader[4].ToString();

                reader.Close();
                con.Close();
            }
        }
        catch (NullReferenceException ex)
        {
            p1.Visible = true;
            p1.Text = ("Processor Usage" + ex.Message);
        }
    }
    protected void Updatep1_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update addshow set  showname='" + Showp2.Text + "', showonnm='" + Showp3.Text + "', showcity='" + Showp4.SelectedValue + "', showphno='" + Showp5.Text + "' where showid='" + (Showp1.Text) + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();

            Showp1.Visible = true;
            Response.Write("<script language=javascript>alert(' Update Profile Successfully.')</script>");

            Showp1.Text = "";
            Showp2.Text = "";
            Showp3.Text = "";
            Showp4.ClearSelection ();
            Showp5.Text = "";


        }
        catch (Exception e1)
        {
            p1.Visible = true;
            p1.Text = "error=" + e1.Message;
        }
    }
}