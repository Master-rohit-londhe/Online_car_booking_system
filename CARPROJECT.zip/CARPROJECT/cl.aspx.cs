﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HiddenField1.Value = Request.QueryString["Id"];

    }
    protected void Button18_Click(object sender, EventArgs e)
    {
        if (Request.QueryString != null)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from custom where customid='" + user3.Text + "' and customuser ='" + psw3.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["id"] = user3.Text;
                Response.Redirect("viewdetail.aspx?Id=" + HiddenField1.Value);
            }
            else
            {
                Response.Write("<script>alert('Please enter valid Username and Password')</script>");
            }

        }
        else
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from custom where customid='" + user3.Text + "' and customuser ='" + psw3.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["id"] = user3.Text;
                Response.Redirect("customprofile.aspx");
            }
            else
            {
                Response.Write("<script>alert('Please enter valid Username and Password')</script>");
            }




        }
    }
    protected void Button17_Click(object sender, EventArgs e)
    {
        if (Request.QueryString != null)
        {
            Response.Redirect("registration.aspx?Id=" + HiddenField1.Value);
        }
        else
        {
            Response.Redirect("registration.aspx");
        }
    }
}