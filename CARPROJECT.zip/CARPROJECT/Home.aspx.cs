﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button18_Command(object sender, CommandEventArgs e)
    {
      //  Response.Redirect("customerlogin.aspx?Id=" + e.CommandArgument);
    }
    protected void Button17_Command(object sender, CommandEventArgs e)
    {
        Response.Redirect("cl.aspx?Id=" + e.CommandArgument);
    }
}